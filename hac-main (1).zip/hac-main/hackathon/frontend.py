from tkinter import *
import sys
import subprocess

import os
import sys
import subprocess
import time
import HandTrankingModule as htm


#os.system('frontend.py')
subprocess.run([sys.executable, 'mainnn.py'], check=True)

